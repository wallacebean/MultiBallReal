

credits and shoutouts to: Glom and Omegegi (you guys fucking carry me)
